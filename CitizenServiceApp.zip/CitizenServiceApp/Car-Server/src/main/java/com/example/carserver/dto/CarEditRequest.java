package com.example.carserver.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CarEditRequest {
    private Long price;
}
