package com.example.carserver.service;

import com.example.carserver.model.Car;

import java.util.List;

public class CarServiceImpl implements CarService{
    @Override
    public Car create(Car car) {
        return null;
    }

    @Override
    public Car getById(Long id) {
        return null;
    }

    @Override
    public List<Car> getAll() {
        return null;
    }

    @Override
    public void deleteById(Long id) {

    }

    @Override
    public Car edit(Car editRequest, Long id) {
        return null;
    }
}
