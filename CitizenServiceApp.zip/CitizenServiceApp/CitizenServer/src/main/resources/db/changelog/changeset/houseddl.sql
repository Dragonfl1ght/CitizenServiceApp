CREATE TABLE IF NOT EXISTS house(
    id SERIAL PRIMARY KEY,
    street VARCHAR(255),
    number INT
)