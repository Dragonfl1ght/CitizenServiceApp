ALTER TABLE passport
    ADD COLUMN serial_number INT,
    ADD COLUMN create_date DATE;

-- private Long id;
-- private Long serialNumber;
-- private OffsetDateTime createDate;