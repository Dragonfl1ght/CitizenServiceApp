package com.kuralesov .citizenservice.service;

import com.kuralesov.citizenservice.model.Passport;

public interface PassportService {
    Passport create();
}
