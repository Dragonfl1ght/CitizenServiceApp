package com.kuralesov .citizenservice.dto;

public class CitizenEditRequest {
    private Integer age;
}
